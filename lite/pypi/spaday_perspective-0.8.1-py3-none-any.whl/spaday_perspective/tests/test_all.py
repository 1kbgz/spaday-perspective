import ast
import json
import re
from pathlib import Path

from spaday import element, generate
from spaday.bootstrap import bootstrap

from spaday_perspective import THEMES, TOKENS, PerspectivePanel, package


def test_perspective_panel_serializes_config_and_theme():
    node = PerspectivePanel(config={"ws_url": "/perspective", "layout": {"viewers": {}}}, theme="dark").to_node()
    assert node["tag"] == "perspective-panel"
    assert node["props"]["config"]["Map"]["ws_url"] == {"Str": "/perspective"}
    assert node["props"]["theme"] == {"Str": "dark"}


def test_perspective_panel_serializes_local_worker_mode():
    node = PerspectivePanel(config={"local": True, "tables": ["trades"]}).to_node()
    assert node["props"]["config"]["Map"]["local"] == {"Bool": True}


def test_viewer_tab_visibility_is_a_python_property():
    for hidden in (True, False):
        node = PerspectivePanel(hide_tabs=hidden).to_node()
        assert node["props"]["hideTabs"] == {"Bool": hidden}


def test_row_actions_are_wrapper_props_and_declare_the_event():
    node = PerspectivePanel(row_actions={"orders": {"id": {"action": "delete", "label": "Delete order"}}}).to_node()
    rule = node["props"]["rowActions"]["Map"]["orders"]["Map"]["id"]["Map"]
    assert rule["action"] == {"Str": "delete"}
    assert rule["label"] == {"Str": "Delete order"}
    assert PerspectivePanel.schema is not None
    assert "perspective-row-action" in PerspectivePanel.schema.events


def test_row_action_example_authors_an_endpoint_action():
    from spaday_perspective.row_actions import page

    serialized = json.dumps(page().to_node())
    assert "perspective-row-action" in serialized
    assert "/orders/delete" in serialized


def test_row_action_tokens_match_the_adapter():
    source = (Path(__file__).parent.parent.parent / "js" / "src" / "ts" / "row-actions.ts").read_text(encoding="utf-8")
    assert {name for name, _ in TOKENS.values()} == set(re.findall(r"--spa-perspective-[\w-]+", source))


def test_token_keywords_serialize_to_the_declared_css_properties():
    for keyword, (property_name, _) in TOKENS.items():
        node = element("div").css(**{keyword: "test"}).to_node()
        assert node["props"]["style"]["Str"] == f"{property_name}: test"


def test_row_action_example_validates_requests_and_updates_the_table():
    from starlette.testclient import TestClient

    from spaday_perspective.row_actions import app, records, table

    original = dict(records)
    try:
        with TestClient(app) as client:
            with client.websocket_connect("/perspective"):
                pass
            for data in ({}, [], {"id": True}, {"id": "1"}):
                assert client.post("/orders/delete", json=data).status_code == 422
            assert client.post("/orders/delete", json={"id": 99}).status_code == 404
            assert client.post("/orders/delete", json={"id": 3}).status_code == 403
            assert table.size() == 3
            assert client.post("/orders/delete", json={"id": 1}).json() == {"message": "Deleted order 1"}
            assert table.size() == 2
            assert 1 not in records
            assert client.post("/orders/delete", json={"id": 1}).status_code == 404
    finally:
        records.clear()
        records.update(original)
        table.replace(list(original.values()))


def test_package_drives_bootstrap_asset_url():
    assert package.name == "perspective"
    assert [(schema.tag, schema.class_name) for schema in package.catalog] == [("perspective-panel", "PerspectivePanel")]
    assert 'src="/components/perspective/cdn/index.js"' in bootstrap(packages=[package])


def test_themes_match_the_panel():
    """THEMES is what a Python author discovers; the map in index.ts is what the panel applies."""
    source = (Path(__file__).parent.parent.parent / "js" / "src" / "ts" / "index.ts").read_text(encoding="utf-8")
    match = re.search(r"const THEMES: Record<string, string> = \{(.*?)\};", source, re.DOTALL)
    assert match is not None
    block = match.group(1)
    assert dict(re.findall(r'(\w+): "([^"]+)"', block)) == THEMES


def test_package_publishes_perspective_under_its_own_specifiers():
    html = bootstrap(packages=[package])
    assert '"@perspective-dev/viewer": "/components/perspective/vendor/@perspective-dev/viewer/dist/cdn/perspective-viewer.js"' in html
    # the bundle's own imports resolve through the map, so it must come first
    assert html.index('type="importmap"') < html.index('src="/components/perspective/cdn/index.js"')


def test_published_imports_are_served():
    for specifier, path in package.imports:
        assert (package.assets_dir / path).is_file(), f"{specifier} maps to {path}, which the build did not produce"
    # the CDN builds find their engine binaries beside them, laid out as in node_modules
    vendor = package.assets_dir / "vendor" / "@perspective-dev"
    assert (vendor / "viewer" / "dist" / "wasm" / "perspective-viewer.wasm").is_file()
    assert (vendor / "server" / "dist" / "wasm" / "perspective-server.wasm").is_file()


def test_generated_component_is_current():
    root = Path(__file__).parent.parent
    fresh = generate(str(root / "components.cem.json"))
    assert ast.dump(ast.parse(fresh)) == ast.dump(ast.parse((root / "components.py").read_text(encoding="utf-8")))


def test_perspective_python_pin_matches_the_bundled_js_client():
    # the frontend serves @perspective-dev/* at an exact version, and Perspective's
    # websocket wire protocol is version-locked but stable within a minor — the Python server
    # requirement must track the bundled client's minor
    root = Path(__file__).parent.parent.parent
    js_version = json.loads((root / "js" / "package.json").read_text(encoding="utf-8"))["dependencies"]["@perspective-dev/client"]
    major, minor = js_version.split(".")[:2]
    expected = f'"perspective-python>={major}.{minor},<{major}.{int(minor) + 1}"'
    assert expected in (root / "pyproject.toml").read_text(encoding="utf-8")
    # every bundled @perspective-dev package moves in lockstep with the client
    deps = json.loads((root / "js" / "package.json").read_text(encoding="utf-8"))["dependencies"]
    assert all(v == js_version for k, v in deps.items() if k.startswith("@perspective-dev/"))


def test_panel_serializes_viewer_options_and_declares_events():
    node = PerspectivePanel(settings=True, autosize=False, throttle=500, themes=["light", "dark"]).to_node()
    assert node["props"]["settings"] == {"Bool": True}
    assert node["props"]["autosize"] == {"Bool": False}
    assert node["props"]["throttle"] == {"Int": 500}
    assert node["props"]["themes"]["List"] == [{"Str": "light"}, {"Str": "dark"}]
    assert PerspectivePanel.schema is not None
    assert "perspective-config-update" in PerspectivePanel.schema.events


def test_panel_serializes_channel_controls_and_restore_options():
    node = PerspectivePanel(
        toolbar=True,
        config={
            "channels": {"trades": {"title": "Trades", "columns": ["price"]}},
            "single_tab": True,
            "master_theme": "light",
        },
    ).to_node()
    assert node["props"]["toolbar"] == {"Bool": True}
    config = node["props"]["config"]["Map"]
    assert config["channels"]["Map"]["trades"]["Map"]["title"] == {"Str": "Trades"}
    assert config["single_tab"] == {"Bool": True}
    assert config["master_theme"] == {"Str": "light"}
