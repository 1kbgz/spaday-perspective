import json
from pathlib import Path

from spaday import ComponentPackage

from .config import Alignment, EditMode, Theme, validate_config
from .panel import PerspectivePanel
from .workspace import migrate_layout

__version__ = "0.10.0"

PerspectiveViewer = PerspectivePanel

# the exact version of each JS library the package serves, written by its JS build
_VERSIONS = Path(__file__).parent / "extension" / "versions.json"

package = ComponentPackage(
    name="perspective",
    assets_dir=Path(__file__).parent / "extension",
    assets=(("js", "cdn/index.js"),),
    components=(PerspectivePanel,),
    # Perspective's modules under its own bare specifiers: a library on the page that imports
    # Perspective resolves to this copy instead of registering the same elements a second time
    imports=(
        ("@perspective-dev/client", "vendor/@perspective-dev/client/dist/cdn/perspective.js"),
        ("@perspective-dev/viewer", "vendor/@perspective-dev/viewer/dist/cdn/perspective-viewer.js"),
        ("@perspective-dev/viewer-charts", "vendor/@perspective-dev/viewer-charts/dist/cdn/perspective-viewer-charts.js"),
        ("@perspective-dev/viewer-datagrid", "vendor/@perspective-dev/viewer-datagrid/dist/cdn/perspective-viewer-datagrid.js"),
    ),
    provides=json.loads(_VERSIONS.read_text(encoding="utf-8")) if _VERSIONS.exists() else {},
)

#: Page mode → the Perspective theme ``<perspective-panel>`` applies for it. A panel with no
#: ``theme`` follows the nearest ``wa-dark`` / ``wa-light`` ancestor to one of these. ``theme`` and
#: ``themes`` accept the keys as shorthands and pass any other name to Perspective unchanged, which
#: is how an application selects a theme of its own once the page carries its CSS::
#:
#:     PerspectiveViewer(...).compute("theme", cond(field("dark"), "Acme Dark", "Acme Light"))
THEMES = {"light": "Pro Light", "dark": "Pro Dark"}

__all__ = [
    "THEMES",
    "Alignment",
    "EditMode",
    "PerspectivePanel",
    "PerspectiveViewer",
    "Theme",
    "migrate_layout",
    "package",
    "validate_config",
]
